"""Regression tests for temporal identity and state-reconstruction correctness.

Run from the extracted package root with:
    python -m unittest discover -s code/tests -v
"""
from __future__ import annotations

import csv
import hashlib
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from schemas import IdentityCluster, ResourceObservation
from tools.identity_graph_tool import IdentityGraphResolver
from tools.state_reconstructor_tool import StateReconstructor


def write_csv(path: Path, headers: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


class IdentityTemporalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        latest_email = "latest@example.test"
        write_csv(
            self.root / "user_identities.csv",
            ["user_id", "name", "email", "phone", "email_hash"],
            [{
                "user_id": "user_001",
                "name": "Alice Example",
                "email": latest_email,
                "phone": "+1-555-0100",
                "email_hash": hashlib.sha256(latest_email.encode()).hexdigest(),
            }],
        )
        write_csv(
            self.root / "user_audit_log.csv",
            ["audit_id", "user_id", "field_name", "old_value", "new_value", "event_time"],
            [
                {
                    "audit_id": "audit_001", "user_id": "user_001", "field_name": "email",
                    "old_value": "old@example.test", "new_value": "mid@example.test",
                    "event_time": "2026-01-15T10:00:00",
                },
                {
                    "audit_id": "audit_002", "user_id": "user_001", "field_name": "email",
                    "old_value": "mid@example.test", "new_value": latest_email,
                    "event_time": "2026-10-01T10:00:00",
                },
            ],
        )
        write_csv(
            self.root / "system_activity.csv",
            ["activity_id", "event_time", "event_type", "source_system", "target_system", "resource_id", "reported_result", "details"],
            [],
        )
        self.resolver = IdentityGraphResolver(self.root)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_future_email_change_does_not_resolve_before_cutoff(self) -> None:
        cutoff = "2026-06-01T00:00:00"
        self.assertEqual(self.resolver.resolve_user_id("old@example.test", cutoff), "user_001")
        self.assertEqual(self.resolver.resolve_user_id("mid@example.test", cutoff), "user_001")
        self.assertIsNone(self.resolver.resolve_user_id("latest@example.test", cutoff))

    def test_cluster_excludes_future_alias_and_audit_id(self) -> None:
        cluster = self.resolver.resolve_cluster("old@example.test", "2026-06-01T00:00:00")
        self.assertEqual(cluster.user_id, "user_001")
        self.assertIn("old@example.test", cluster.emails)
        self.assertIn("mid@example.test", cluster.emails)
        self.assertNotIn("latest@example.test", cluster.emails)
        self.assertEqual(cluster.audit_ids, ["audit_001"])

    def test_ambiguous_historical_alias_is_not_arbitrarily_assigned(self) -> None:
        # The same historical alias attached to two identity clusters is not safe to
        # resolve by load order; the resolver must return None.
        with (self.root / "user_identities.csv").open("a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["user_id", "name", "email", "phone", "email_hash"])
            writer.writerow({
                "user_id": "user_002", "name": "Bob Example", "email": "bob@example.test",
                "phone": "+1-555-0200", "email_hash": hashlib.sha256(b"bob@example.test").hexdigest(),
            })
        with (self.root / "user_audit_log.csv").open("a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["audit_id", "user_id", "field_name", "old_value", "new_value", "event_time"])
            writer.writerow({
                "audit_id": "audit_003", "user_id": "user_002", "field_name": "email",
                "old_value": "old@example.test", "new_value": "bob@example.test",
                "event_time": "2026-02-01T10:00:00",
            })
        resolver = IdentityGraphResolver(self.root)
        self.assertIsNone(resolver.resolve_user_id("old@example.test", "2026-06-01T00:00:00"))


class StateReconstructionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def write_activities(self, rows: list[dict[str, str]]) -> None:
        write_csv(
            self.root / "system_activity.csv",
            ["activity_id", "event_time", "event_type", "source_system", "target_system", "resource_id", "reported_result", "details"],
            rows,
        )

    @staticmethod
    def observation(
        file_id: str,
        system_id: str,
        resource_id: str,
        *,
        user_id: str | None = None,
        state: str = "PRESENT",
        observed_at: str = "2026-01-01T00:00:00",
    ) -> ResourceObservation:
        return ResourceObservation(
            file_id=file_id,
            file_captured_at=observed_at,
            observed_at=observed_at,
            system_id=system_id,
            resource_id=resource_id,
            data_category="BACKUP_ARCHIVE" if system_id == "backup_service" else "USER_PROFILE",
            state=state,
            user_id=user_id,
            has_exposed_pii=True,
        )

    def test_resource_link_is_system_specific(self) -> None:
        self.write_activities([])
        obs = self.observation("evidence_001", "support_platform", "shared_001")
        reconstructor = StateReconstructor(self.root, [obs], [], [])
        cluster = IdentityCluster(user_id="user_001")
        cluster.linked_resources["shared_001"] = "search_service"
        resource_map, risks = reconstructor.reconstruct_system_states(cluster, "2026-12-31T00:00:00")
        self.assertNotIn(("support_platform", "shared_001"), resource_map)
        self.assertEqual(risks, [])

    def test_restore_without_prior_deletion_is_not_recreation_risk(self) -> None:
        self.write_activities([{
            "activity_id": "activity_sync", "event_time": "2026-01-03T00:00:00",
            "event_type": "RESTORE_BACKUP", "source_system": "backup_service",
            "target_system": "backup_service", "resource_id": "backup_001",
            "reported_result": "SUCCESS", "details": "restore completed",
        }])
        obs = self.observation("evidence_001", "backup_service", "backup_001", user_id="user_001")
        reconstructor = StateReconstructor(self.root, [], [], [obs])
        cluster = IdentityCluster(user_id="user_001")
        _, risks = reconstructor.reconstruct_system_states(cluster, "2026-12-31T00:00:00")
        self.assertEqual(risks, [])
        self.assertEqual(obs.state, "PRESENT")

    def test_restore_after_delete_does_not_mutate_shared_observation(self) -> None:
        self.write_activities([
            {
                "activity_id": "activity_delete", "event_time": "2026-01-02T00:00:00",
                "event_type": "DELETE_RECORD", "source_system": "backup_service",
                "target_system": "backup_service", "resource_id": "backup_001",
                "reported_result": "SUCCESS", "details": "delete for user_001",
            },
            {
                "activity_id": "activity_restore", "event_time": "2026-01-03T00:00:00",
                "event_type": "RESTORE_BACKUP", "source_system": "backup_service",
                "target_system": "backup_service", "resource_id": "backup_001",
                "reported_result": "SUCCESS", "details": "restore completed",
            },
        ])
        obs = self.observation("evidence_001", "backup_service", "backup_001", user_id="user_001")
        reconstructor = StateReconstructor(self.root, [], [], [obs])
        cluster = IdentityCluster(user_id="user_001")
        resource_map, risks = reconstructor.reconstruct_system_states(cluster, "2026-12-31T00:00:00")
        self.assertEqual(resource_map[("backup_service", "backup_001")].state, "ACTIVE")
        self.assertEqual(obs.state, "PRESENT")
        self.assertEqual(risks, [("backup_service", "backup_001", "activity_restore")])

    def test_account_suffix_alone_does_not_synthesize_absence(self) -> None:
        self.write_activities([{
            "activity_id": "activity_delete", "event_time": "2026-01-02T00:00:00",
            "event_type": "DELETE_RECORD", "source_system": "account_service",
            "target_system": "account_service", "resource_id": "account_001",
            "reported_result": "SUCCESS", "details": "processed successfully",
        }])
        reconstructor = StateReconstructor(self.root, [], [], [])
        cluster = IdentityCluster(user_id="user_001")
        resource_map, _ = reconstructor.reconstruct_system_states(cluster, "2026-12-31T00:00:00")
        self.assertEqual(resource_map, {})


if __name__ == "__main__":
    unittest.main()
