"""
Deterministic Transitive Identity Graph Resolver.

Resolves current and historical identifiers from the participant-facing identity,
audit, and activity files. Case-level resolution is evaluated as of ``audit_at``;
post-cutoff identity changes must not affect a historical audit.
"""

from __future__ import annotations

import csv
import hashlib
import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from schemas import IdentityCluster


class IdentityGraphResolver:
    """Resolve identity aliases conservatively, with point-in-time support."""

    _LINK_RE = re.compile(
        r"linked\s+(?P<rid>[a-z0-9_]+)\s+\((?P<label>[^)]+)\)\s+to\s+(?P<email>[^\s]+)\s+and\s+(?P<uid>user_\d+)",
        re.IGNORECASE,
    )
    _ATTACH_LINK_RE = re.compile(
        r"confirmed\s+(?P<rid>[a-z0-9_]+)\s+\((?P<label>[^)]+)\)\s+belongs\s+only\s+to\s+(?P<email>[^\s]+)\s+and\s+(?P<uid>user_\d+)",
        re.IGNORECASE,
    )
    _CLASSIFY_NON_DEL_RE = re.compile(
        r"classified\s+request\s+for\s+(?P<rid>account_\d+)\s+as\s+non-deletion",
        re.IGNORECASE,
    )

    _FIELD_TO_COLUMN = {
        "email": "email",
        "email_hash": "email_hash",
        "phone": "phone",
        "name": "name",
        "full_name": "name",
    }

    def __init__(self, dataset_dir: Path) -> None:
        self.dataset_dir = dataset_dir
        self.users_by_id: Dict[str, Dict[str, str]] = {}
        self.audit_rows_by_uid: Dict[str, List[Dict[str, str]]] = {}
        # Retained for compatibility with callers that inspect these indexes.
        # Resolution itself uses candidate sets and refuses ambiguous aliases.
        self.email_to_uid: Dict[str, str] = {}
        self.hash_to_uid: Dict[str, str] = {}
        self.phone_to_uid: Dict[str, str] = {}
        self.catalog_links_by_uid: Dict[str, List[Tuple[str, str, str, str]]] = {}
        self.non_deletion_accounts: Set[str] = set()

        self._load_user_identities()
        self._load_user_audit_log()
        self._load_activity_identity_links()

    @staticmethod
    def sha256_hex(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest().lower()

    @staticmethod
    def normalize_phone(phone: str) -> str:
        return "".join(ch for ch in phone if ch.isdigit() or ch == "+")

    def _load_user_identities(self) -> None:
        path = self.dataset_dir / "user_identities.csv"
        if not path.exists():
            return
        with path.open("r", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                uid = (row.get("user_id") or "").strip()
                if not uid:
                    continue
                row = {k: (v or "").strip() for k, v in row.items()}
                self.users_by_id[uid] = row
                email = row.get("email", "")
                if email:
                    self.email_to_uid.setdefault(email.lower(), uid)
                email_hash = row.get("email_hash", "").lower()
                if email_hash:
                    self.hash_to_uid.setdefault(email_hash, uid)
                if email:
                    self.hash_to_uid.setdefault(self.sha256_hex(email.lower()), uid)
                    self.hash_to_uid.setdefault(self.sha256_hex(email), uid)
                phone = self.normalize_phone(row.get("phone", ""))
                if phone:
                    self.phone_to_uid.setdefault(phone, uid)

    def _load_user_audit_log(self) -> None:
        path = self.dataset_dir / "user_audit_log.csv"
        if not path.exists():
            return
        with path.open("r", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                uid = (row.get("user_id") or "").strip()
                if not uid:
                    continue
                row = {k: (v or "").strip() for k, v in row.items()}
                self.audit_rows_by_uid.setdefault(uid, []).append(row)
                field_name = row.get("field_name", "").lower()
                for col in ("old_value", "new_value"):
                    value = row.get(col, "")
                    if not value:
                        continue
                    if field_name == "email":
                        self.email_to_uid.setdefault(value.lower(), uid)
                        self.hash_to_uid.setdefault(self.sha256_hex(value.lower()), uid)
                        self.hash_to_uid.setdefault(self.sha256_hex(value), uid)
                    elif field_name == "email_hash":
                        self.hash_to_uid.setdefault(value.lower(), uid)
                    elif field_name == "phone":
                        self.phone_to_uid.setdefault(self.normalize_phone(value), uid)

        for uid in self.audit_rows_by_uid:
            self.audit_rows_by_uid[uid].sort(
                key=lambda r: (r.get("event_time", ""), r.get("audit_id", ""))
            )

    def _load_activity_identity_links(self) -> None:
        path = self.dataset_dir / "system_activity.csv"
        if not path.exists():
            return
        with path.open("r", encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                etype = (row.get("event_type") or "").strip()
                details = (row.get("details") or "").strip()
                ev_time = (row.get("event_time") or "").strip()
                target_sys = (row.get("target_system") or "").strip()
                rid = (row.get("resource_id") or "").strip()

                if etype == "LINK_RESOURCE_IDENTITY":
                    match = self._LINK_RE.search(details) or self._ATTACH_LINK_RE.search(details)
                    if match:
                        uid = match.group("uid").strip()
                        email = match.group("email").strip().rstrip(".;,")
                        self.email_to_uid.setdefault(email.lower(), uid)
                        self.catalog_links_by_uid.setdefault(uid, []).append(
                            (ev_time, rid, target_sys, email)
                        )
                elif etype == "CLASSIFY_REQUEST":
                    match = self._CLASSIFY_NON_DEL_RE.search(details)
                    if match:
                        self.non_deletion_accounts.add(match.group("rid").strip())

    @classmethod
    def _value_matches_identifier(cls, field_name: str, value: str, identifier: str) -> bool:
        """Compare identifiers using field-appropriate normalization."""
        value = (value or "").strip()
        identifier = (identifier or "").strip()
        if not value or not identifier:
            return False

        field = field_name.lower()
        if field in {"email", "email_address"}:
            value_low = value.lower()
            identifier_low = identifier.lower()
            return identifier_low in {
                value_low,
                cls.sha256_hex(value),
                cls.sha256_hex(value_low),
            }
        if field == "email_hash":
            return value.lower() == identifier.lower()
        if field == "phone":
            normalized_value = cls.normalize_phone(value)
            normalized_identifier = cls.normalize_phone(identifier)
            return bool(normalized_value) and normalized_value == normalized_identifier
        if field in {"user_id", "uid"}:
            return value.lower() == identifier.lower()
        return False

    def _row_matches_identifier(self, row: Dict[str, str], identifier: str) -> bool:
        uid = (row.get("user_id") or "").strip()
        if uid and self._value_matches_identifier("user_id", uid, identifier):
            return True
        for field in ("email", "email_hash", "phone"):
            if self._value_matches_identifier(field, row.get(field, ""), identifier):
                return True
        return False

    def _user_row_as_of(self, uid: str, audit_at: str) -> Dict[str, str]:
        """Rewind fields changed after ``audit_at`` to their prior values."""
        row = dict(self.users_by_id.get(uid, {}))
        future_rows = [
            r for r in self.audit_rows_by_uid.get(uid, [])
            if (r.get("event_time") or "") > audit_at
        ]
        # Undo later changes in reverse chronological order, starting from the
        # latest snapshot stored in user_identities.csv.
        for audit_row in reversed(future_rows):
            column = self._FIELD_TO_COLUMN.get((audit_row.get("field_name") or "").lower())
            if not column:
                continue
            row[column] = (audit_row.get("old_value") or "").strip()
        return row

    def resolve_user_id(
        self, identifier: Optional[str], audit_at: Optional[str] = None
    ) -> Optional[str]:
        """Resolve an identifier only when its identity association is unambiguous.

        When ``audit_at`` is supplied, later audit-log changes and later identity-link
        activities are excluded. In the no-cutoff ingestion path, all available history
        is considered, but ambiguous aliases still return ``None`` instead of whichever
        user happened to be loaded last.
        """
        if not identifier:
            return None
        value = str(identifier).strip()
        if not value or value.lower() in {"null", "none", "no direct identifier"}:
            return None

        low = value.lower()
        if low.startswith("user_") and low in self.users_by_id:
            return low

        candidates: Set[str] = set()
        for uid, current_row in self.users_by_id.items():
            row = self._user_row_as_of(uid, audit_at) if audit_at is not None else current_row
            if self._row_matches_identifier(row, value):
                candidates.add(uid)

            for audit_row in self.audit_rows_by_uid.get(uid, []):
                if audit_at is not None and (audit_row.get("event_time") or "") > audit_at:
                    continue
                field_name = (audit_row.get("field_name") or "").lower()
                if field_name not in {"email", "email_hash", "phone"}:
                    continue
                for col in ("old_value", "new_value"):
                    if self._value_matches_identifier(field_name, audit_row.get(col, ""), value):
                        candidates.add(uid)

            for event_time, _rid, _target_sys, linked_email in self.catalog_links_by_uid.get(uid, []):
                if audit_at is not None and event_time > audit_at:
                    continue
                if self._value_matches_identifier("email", linked_email, value):
                    candidates.add(uid)

        return next(iter(candidates)) if len(candidates) == 1 else None

    def resolve_cluster(self, seed_email: str, audit_at: str) -> IdentityCluster:
        """Build the identity cluster using only identity evidence available by ``audit_at``."""
        email_clean = seed_email.strip()
        email_low = email_clean.lower()
        uid = self.resolve_user_id(email_low, audit_at=audit_at)
        if uid is None:
            uid = f"unresolved_{self.sha256_hex(email_low)[:8]}"

        cluster = IdentityCluster(user_id=uid)
        cluster.emails.add(email_low)
        cluster.raw_emails.add(email_clean)
        cluster.email_hashes.add(self.sha256_hex(email_low))
        cluster.email_hashes.add(self.sha256_hex(email_clean))

        if uid in self.users_by_id:
            row = self._user_row_as_of(uid, audit_at)
            name = row.get("name", "").strip()
            current_email = row.get("email", "").strip()
            phone = row.get("phone", "").strip()
            email_hash = row.get("email_hash", "").strip().lower()

            if name:
                cluster.primary_name = name
                cluster.names.add(name)
            if current_email:
                cluster.emails.add(current_email.lower())
                cluster.raw_emails.add(current_email)
                cluster.email_hashes.add(self.sha256_hex(current_email.lower()))
                cluster.email_hashes.add(self.sha256_hex(current_email))
            if phone:
                cluster.phones.add(phone)
            if email_hash:
                cluster.email_hashes.add(email_hash)

        # Only audit events at or before the case's temporal cutoff may contribute
        # historical identifiers or audit evidence IDs.
        for audit_row in self.audit_rows_by_uid.get(uid, []):
            if (audit_row.get("event_time") or "") > audit_at:
                continue
            if audit_row.get("audit_id"):
                cluster.audit_ids.append(audit_row["audit_id"].strip())
            field_name = (audit_row.get("field_name") or "").lower()
            for col in ("old_value", "new_value"):
                value = (audit_row.get(col) or "").strip()
                if not value:
                    continue
                if field_name == "email":
                    cluster.emails.add(value.lower())
                    cluster.raw_emails.add(value)
                    cluster.email_hashes.add(self.sha256_hex(value.lower()))
                    cluster.email_hashes.add(self.sha256_hex(value))
                elif field_name == "email_hash":
                    cluster.email_hashes.add(value.lower())
                elif field_name == "phone":
                    cluster.phones.add(value)
                elif field_name in {"name", "full_name"}:
                    cluster.names.add(value)

        for event_time, resource_id, target_system, linked_email in self.catalog_links_by_uid.get(uid, []):
            if event_time <= audit_at:
                cluster.linked_resources[resource_id] = target_system
                cluster.emails.add(linked_email.lower())
                cluster.raw_emails.add(linked_email)
                cluster.email_hashes.add(self.sha256_hex(linked_email.lower()))

        return cluster
