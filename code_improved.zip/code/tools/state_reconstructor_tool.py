"""
Temporal State Reconstruction Engine (`code/tools/state_reconstructor_tool.py`)
Reconstructs point-in-time resource states at `audit_at` by filtering activity streams
and resolving operational claims against physical evidence observations.
"""

from __future__ import annotations

import csv
import re
from dataclasses import replace
from pathlib import Path
from typing import Dict, List, Tuple

from schemas import ActivityEvent, IdentityCluster, ResourceObservation


class StateReconstructor:
    """
    Evaluates resource lifecycles up to `audit_at`, detecting zombie recreations
    via sync jobs or backup restores.
    """

    def __init__(
        self,
        dataset_dir: Path,
        sql_observations: List[ResourceObservation],
        structured_observations: List[ResourceObservation],
        multimodal_observations: List[ResourceObservation],
    ) -> None:
        self.dataset_dir = dataset_dir
        self.all_observations: List[ResourceObservation] = (
            sql_observations + structured_observations + multimodal_observations
        )
        self.activities: List[ActivityEvent] = []
        self._load_system_activity()

    def _load_system_activity(self) -> None:
        path = self.dataset_dir / "system_activity.csv"
        if not path.exists():
            return
        with path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                self.activities.append(
                    ActivityEvent(
                        activity_id=row["activity_id"].strip(),
                        event_time=row["event_time"].strip(),
                        event_type=row["event_type"].strip(),
                        source_system=row["source_system"].strip(),
                        target_system=row["target_system"].strip(),
                        resource_id=row["resource_id"].strip(),
                        reported_result=row["reported_result"].strip(),
                        details=row["details"].strip(),
                    )
                )
        self.activities.sort(key=lambda a: (a.event_time, a.activity_id))

    def reconstruct_system_states(
        self,
        cluster: IdentityCluster,
        audit_at: str,
    ) -> Tuple[Dict[Tuple[str, str], ResourceObservation], List[Tuple[str, str, str]]]:
        """
        Reconstructs authoritative resource states at `audit_at` for all items linked
        to the user's identity cluster, returning `{(system_id, resource_id): observation}`
        and active recreation risks.
        """
        # Filter observations up to audit_at
        valid_obs = [
            o
            for o in self.all_observations
            if o.observed_at <= audit_at and o.file_captured_at <= audit_at
        ]

        # Map by (system_id, resource_id) keeping latest observation <= audit_at
        resource_map: Dict[Tuple[str, str], ResourceObservation] = {}
        for obs in sorted(valid_obs, key=lambda o: (o.observed_at, o.file_id)):
            key = (obs.system_id, obs.resource_id)
            # Check if this observation belongs to the user cluster
            belongs = (
                obs.user_id == cluster.user_id
                or cluster.matches_identifier(obs.email)
                or cluster.matches_identifier(obs.email_hash)
                or cluster.matches_identifier(obs.phone)
                or cluster.linked_resources.get(obs.resource_id) == obs.system_id
            )
            if belongs:
                if obs.system_id in {"legal_service", "object_storage"}:
                    continue
                resource_map[key] = obs

        # A deletion readback may establish an absent account only when the activity
        # is directly linked to this account identity. Never infer ownership from an
        # account/user numeric suffix, and never borrow an unrelated evidence file ID.
        for act in self.activities:
            if act.event_time > audit_at or act.event_type != "DELETE_RECORD":
                continue
            if act.reported_result not in {"SUCCESS", "PARTIAL"}:
                continue
            if act.target_system != "account_service" or not act.resource_id.startswith("account_"):
                continue
            explicitly_linked = (
                cluster.linked_resources.get(act.resource_id) == "account_service"
                or self._activity_mentions_cluster(act.details, cluster)
            )
            key = ("account_service", act.resource_id)
            if explicitly_linked and key not in resource_map:
                resource_map[key] = ResourceObservation(
                    # Activity IDs are valid evidence references under the output contract.
                    # Do not substitute an arbitrary account-service file from another case.
                    file_id=act.activity_id,
                    file_captured_at=act.event_time,
                    observed_at=act.event_time,
                    system_id="account_service",
                    resource_id=act.resource_id,
                    data_category="USER_PROFILE",
                    state="ABSENT",
                    user_id=cluster.user_id,
                    has_exposed_pii=False,
                    source_table_or_collection="identity-linked deletion readback",
                )

        # Only call a sync/restore a recreation risk when it occurs after a successful
        # deletion of the same resource. A generic successful sync is not, by itself,
        # proof that deleted data was recreated.
        eligible_activities = [a for a in self.activities if a.event_time <= audit_at]
        deletion_events: Dict[Tuple[str, str], List[ActivityEvent]] = {}
        for act in eligible_activities:
            if act.event_type != "DELETE_RECORD" or act.reported_result not in {"SUCCESS", "PARTIAL"}:
                continue
            key = (act.target_system, act.resource_id)
            if key in resource_map or self._activity_mentions_cluster(act.details, cluster):
                deletion_events.setdefault(key, []).append(act)

        recreation_risks: List[Tuple[str, str, str]] = []
        for act in eligible_activities:
            if act.event_type not in {"RESTORE_BACKUP", "SYNC_RECORD"} or act.reported_result != "SUCCESS":
                continue
            key = (act.target_system, act.resource_id)
            obs = resource_map.get(key)
            if obs is None:
                continue

            prior_deletions = [d for d in deletion_events.get(key, []) if d.event_time < act.event_time]
            if not prior_deletions:
                continue
            later_deletions = [d for d in deletion_events.get(key, []) if d.event_time > act.event_time]
            if later_deletions:
                continue
            # A later physical absence observation supersedes an earlier restore/sync.
            if obs.observed_at > act.event_time and obs.state == "ABSENT":
                continue

            new_state = "PRESENT" if act.event_type == "SYNC_RECORD" else "ACTIVE"
            # Observations are shared across cases; never mutate the original object.
            resource_map[key] = replace(obs, state=new_state)
            recreation_risks.append((act.target_system, act.resource_id, act.activity_id))

        return resource_map, recreation_risks

    @staticmethod
    def _activity_mentions_cluster(details: str, cluster: IdentityCluster) -> bool:
        """Accept an activity link only when it contains a known identifier token."""
        known = set(cluster.emails)
        known.update(cluster.email_hashes)
        known.update(cluster.phones)
        known.add(cluster.user_id)
        text = details.lower()
        return any(
            re.search(r"(?<![\w.+-])" + re.escape(identifier.lower()) + r"(?![\w.+-])", text)
            for identifier in known
            if identifier
        )

